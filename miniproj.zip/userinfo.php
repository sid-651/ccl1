<?php
$con = mysqli_connect('localhost', 'root', '', 'ccldata');
if ($con) {
    echo "Connection successful";
} else {
    echo "Connecting failed";
}

$email = $_POST['email'] ?? '';
$mobile = $_POST['mobile'] ?? '';
$comment = $_POST['comment'] ?? '';

$query = "INSERT INTO userinfodata (email, mobile, comment) 
          VALUES ('$email', '$mobile', '$comment')";
mysqli_query($con, $query);

echo $query;
header("location:index.php");
?>
