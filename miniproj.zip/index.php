<!DOCTYPE html>
<html lang="en">
<head>
    <title>Document</title>
    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="style.css">
</head>
<body>


<nav class="navbar navbar-expand-lg navbar-dark bg-dark bg-body-tertiary">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">CCL MP</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">services</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="about.php">about</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">contact</a>
        </li>
        
        
        
      </ul>
      <form class="d-flex" role="search">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form>
    </div>
  </div>
</nav>



<div id="demo" class="carousel slide" data-ride="carousel">

  <!-- Indicators -->
  <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
    <li data-target="#demo" data-slide-to="1"></li>
    <li data-target="#demo" data-slide-to="2"></li>
  </ul>
  
  <!-- The slideshow -->
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="images/madrid.jpg" alt="MADRID" width="1600" height="700">
    </div>
    <div class="carousel-item">
      <img src="images/paris.jpg" alt="PARIS" width="1600" height="700">
    </div>
    <div class="carousel-item">
      <img src="images/london.jpg" alt="UNITED KINGDOM" width="1600" height="700">
    </div>
  </div>
  
  <!-- Left and right controls -->
  <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
</div>

<section class="my-5">
    <div class="py-5">
      <h2 class="text-center">About us</h2>
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-4 col-md-10 col-12">
                <img src="images/monaco.jpg" class="img-fluid aboutimg">
            </div>
            <div class="col-lg-6 col-md-6 col-12">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-12">
                        <h2 class="Display-4">CCL MINI-PROJECT</h2>
                        <p class="py-5">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Modi incidunt culpa, corrupti saepe sapiente tempora magni adipisci dolor rerum voluptatibus explicabo ab sunt laudantium eius officiis qui consectetur officia obcaecati atque numquam, odio vero. Officiis aperiam commodi placeat rerum natus!</p>
                        <a href="about.php" class="btn btn-success">Check more</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="my-5">
  <div class="py-5">
    <h2 class="text-center">Our Services</h2>
  </div>

  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-4 col-md-4 col-12">
        <div class="card">
          <img class="card-img-top custom-img" src="images/albania.jpeg" alt="Card image">
          <div class="card-body">
            <h4 class="card-title">Albania</h4>
            <p class="card-text">Sample text</p>
            <a href="#" class="btn btn-primary">See Profile</a>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-4 col-12">
        <div class="card">
          <img class="card-img-top custom-img" src="images/LA.jpeg" alt="Card image">
          <div class="card-body">
            <h4 class="card-title">LA</h4>
            <p class="card-text">Sample text</p>
            <a href="#" class="btn btn-primary">See Profile</a>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-4 col-12">
        <div class="card">
          <img class="card-img-top custom-img" src="images/brazil.jpeg" alt="Card image">
          <div class="card-body">
            <h4 class="card-title">Brazil</h4>
            <p class="card-text">Sample text</p>
            <a href="#" class="btn btn-primary">See Profile</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>


<section class="my-5">
  <div class="py-5">
    <h2 class="text-center">Gallery</h2>
  </div>

  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-4 col-md-4 col-12">
        <img src="images/monaco2.jpg" class="img-fluid custom-img" alt="">
      </div>
      <div class="col-lg-4 col-md-4 col-12">
        <img src="images/flight.jpg" class="img-fluid custom-img" alt="">
      </div>
      <div class="col-lg-4 col-md-4 col-12">
        <img src="images/blyat.jpg" class="img-fluid custom-img" alt="">
      </div>
    </div>
  </div>
</section>

<section class="my-5">
  <div class="py-5">
    <h2 class="text-center">Our Services</h2>
  </div>

  <div class="w-50 m-auto">
    <form action="userinfo.php" method="post">
      <div class="form-group">
        <label for="">username</label>
        <input type=" text" name="user" autocomplete="off" class="form-control">
      </div>
    
    <div class="form-group">
        <label for="">Email ID</label>
        <input type=" text" name="email" autocomplete="off" class="form-control">
    </div>
    
    <div class="form-group">
        <label for="">Mobile No.</label>
        <input type=" text" name="mobile" autocomplete="off" class="form-control">
    </div>
    
    <div class="form-group">
        <label for="">Comment</label>
        <textarea class="form-control" name="comment">
        </textarea>
    </div>
    <button type="submit" class="btn btn-success">Submit</button>
    </form>


  </div>
</section>

<footer class="bg-dark text-white text-center">
<p>MINI-PROJECT:
Arya Pawar 641,
Sidharth Salian 647,
Saad Shaikh 652
</p>
</footer>




<script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>