<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<div class="jumbotron">
  <h1>HOLO</h1>
  <p>MINI-PROJECT</p>
</div>
</body>
</html>